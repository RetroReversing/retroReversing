	.file	1 "cases/naked.c"
	.version	"01.01"
gcc2_compiled.:
	.text
	.align	2
	.globl	naked_entry
	.type	 naked_entry,@function
	.ent	naked_entry
naked_entry:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
 #APP
	.set noreorder
	jr $31
	nop
	.set reorder
 #NO_APP
	j	$31
	.end	naked_entry
.Lfe1:
	.size	 naked_entry,.Lfe1-naked_entry
