	.file	1 "cases/control.c"
	.version	"01.01"
gcc2_compiled.:
	.text
	.align	2
	.globl	ordinary
	.type	 ordinary,@function
	.ent	ordinary
ordinary:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	sll	$2,$4,1
	addu	$2,$2,$4
	.set	noreorder
	.set	nomacro
	j	$31
	addu	$2,$2,$5
	.set	macro
	.set	reorder

	.end	ordinary
.Lfe1:
	.size	 ordinary,.Lfe1-ordinary
