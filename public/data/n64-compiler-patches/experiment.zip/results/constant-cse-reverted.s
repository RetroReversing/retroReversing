	.file	1 "cases/constant.c"
	.version	"01.01"
gcc2_compiled.:
	.text
	.align	2
	.globl	constant_reuse
	.type	 constant_reuse,@function
	.ent	constant_reuse
constant_reuse:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, extra= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,-2147483648			# 0x80000000
	subu	$4,$4,$2
	subu	$2,$5,$2
	.set	noreorder
	.set	nomacro
	j	$31
	xor	$2,$4,$2
	.set	macro
	.set	reorder

	.end	constant_reuse
.Lfe1:
	.size	 constant_reuse,.Lfe1-constant_reuse
